
x=input("Please enter last name: ")
y=int(input("Please enter # of dependents: "))
z=int(input("Please enter gross income: "))

adjincome=z - (y * 12000)

if(adjincome>=50000):
  rate=0.2
else:
  rate=0.1
  
tax=adjincome * rate

if(tax==0):
  taxrate=100
  


print("Last name: " , x)
print("Gross income: " , z)
print("# of dependents: " , y)
print("Adjusted Income: " , adjincome)
print("Income tax: " , tax)