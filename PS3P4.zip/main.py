
x=(input("Please enter item name: "))
y=int(input("Please enter cost of item: "))

if(y>=1000):
  fee=.1
else:
  fee=.05

extprice=y * fee
total=y + extprice

print("Item name: " , x)
print("Item cost: " , y)
print("Warrantee cost: " , extprice)
print("Total: " , total)