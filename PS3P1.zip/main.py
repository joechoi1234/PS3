
x=int(input("Please enter a quantity: "))

if(x>= 1000):
  y=3.00
else:
  y=5.00
  
c= x * y
tax= c * .07
total= c - tax

print("Quanity: " , x)
print("Unit Price: " , y)
print("Extended Price: " , c)
print("Tax: " , tax)
print("Total: " , total)
