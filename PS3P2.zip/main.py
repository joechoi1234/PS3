
item=(input("Choose item a or b: "))
x=int(input("Enter quantity: "))

if(item=="a"):
  unitprice=10.00
else:
  unitprice=20.00

c=x * unitprice

print("Item: " , item)
print("Unit Price: " , unitprice) 
print("Extended Price: " , c)
