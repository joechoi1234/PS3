
x=int(input("Enter amount of books: "))
y=int(input("Enter cost per book: "))

c=x * y

if(c>=50.00):
  fee=0.00
else:
  fee=25.00

total=c + fee

print("Fee: " , fee)
print("Total: " , total)